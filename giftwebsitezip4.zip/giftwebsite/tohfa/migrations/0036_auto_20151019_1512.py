# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('tohfa', '0035_invoice_address'),
    ]

    operations = [
        migrations.RemoveField(
            model_name='guest_account',
            name='title',
        ),
        migrations.AlterField(
            model_name='guest_account',
            name='mobile',
            field=models.IntegerField(max_length=10),
        ),
        migrations.AlterField(
            model_name='guest_account',
            name='zip_code',
            field=models.IntegerField(max_length=6),
        ),
    ]
