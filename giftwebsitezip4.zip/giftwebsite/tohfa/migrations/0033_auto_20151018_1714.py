# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('tohfa', '0032_auto_20151018_1711'),
    ]

    operations = [
        migrations.RenameField(
            model_name='guest_account',
            old_name='Zip_code',
            new_name='zip_code',
        ),
    ]
