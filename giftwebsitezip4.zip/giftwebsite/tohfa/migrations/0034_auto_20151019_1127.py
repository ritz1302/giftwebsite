# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('tohfa', '0033_auto_20151018_1714'),
    ]

    operations = [
        migrations.AlterField(
            model_name='guest_account',
            name='title',
            field=models.CharField(max_length=10),
        ),
    ]
