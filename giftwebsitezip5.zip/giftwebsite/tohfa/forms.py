import datetime
from django import forms
from django.contrib.auth.models import User
from .models import *
from django.contrib.auth.forms import UserCreationForm
from captcha.fields import CaptchaField
from simplemathcaptcha.fields import MathCaptchaField
from django.contrib.admin import widgets


Mr = 0
Miss = 1
PREFERRED_TITLE_CHOICES = (
    (Mr, 'Mr'),
    (Miss, 'Miss'),
)

class CreateAcount(forms.ModelForm):
    captcha = CaptchaField()
    class Meta:
        model= User
        fields= ('username', 'first_name', 'last_name', 'email', 'password')

    def __init__(self, *args, **kwargs):
        super(CreateAcount, self).__init__(*args, **kwargs)



class CreateAcount2(forms.ModelForm):
    class Meta:
        model= User
        fields= ('username', 'first_name', 'last_name', 'email')

    def __init__(self, *args, **kwargs):
        super(CreateAcount2, self).__init__(*args, **kwargs)


class InstantAcount(forms.ModelForm):
    class Meta:
        model= Guest_account
        title = forms.ChoiceField(choices=PREFERRED_TITLE_CHOICES,
                                        widget=forms.RadioSelect())
        fields= "__all__"

    def __init__(self, *args, **kwargs):
        super(InstantAcount, self).__init__(*args, **kwargs)
        self.fields['date_of_birth'].widget = widgets.AdminSplitDateTime()


class AddressForm(forms.ModelForm):
    class Meta:
        model = Address
        fields = "__all__"

    def __init__(self, *args, **kwargs):
        super(AddressForm, self).__init__(*args, **kwargs)
