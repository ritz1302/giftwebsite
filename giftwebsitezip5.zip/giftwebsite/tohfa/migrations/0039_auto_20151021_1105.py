# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('tohfa', '0038_auto_20151020_1808'),
    ]

    operations = [
        migrations.AddField(
            model_name='address',
            name='additional_info',
            field=models.CharField(max_length=500, default='1'),
            preserve_default=False,
        ),
        migrations.AddField(
            model_name='address',
            name='company',
            field=models.CharField(max_length=300, blank=True),
        ),
        migrations.AddField(
            model_name='address',
            name='home_phone',
            field=models.IntegerField(default=1),
            preserve_default=False,
        ),
    ]
