# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('tohfa', '0039_auto_20151021_1105'),
    ]

    operations = [
        migrations.AlterField(
            model_name='address',
            name='additional_info',
            field=models.CharField(max_length=500, blank=True),
        ),
        migrations.AlterField(
            model_name='address',
            name='address_2',
            field=models.CharField(max_length=200, blank=True),
        ),
    ]
