# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('tohfa', '0037_address'),
    ]

    operations = [
        migrations.AlterField(
            model_name='address',
            name='mobile',
            field=models.IntegerField(),
        ),
        migrations.AlterField(
            model_name='address',
            name='zip_code',
            field=models.IntegerField(),
        ),
        migrations.AlterField(
            model_name='guest_account',
            name='mobile',
            field=models.IntegerField(),
        ),
        migrations.AlterField(
            model_name='guest_account',
            name='zip_code',
            field=models.IntegerField(),
        ),
        migrations.AlterField(
            model_name='invoice_address',
            name='home_phone',
            field=models.IntegerField(),
        ),
        migrations.AlterField(
            model_name='invoice_address',
            name='mobile',
            field=models.IntegerField(),
        ),
        migrations.AlterField(
            model_name='invoice_address',
            name='zip_code',
            field=models.IntegerField(),
        ),
    ]
