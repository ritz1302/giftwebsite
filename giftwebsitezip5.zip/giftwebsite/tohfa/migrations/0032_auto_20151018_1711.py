# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('tohfa', '0031_guest_account'),
    ]

    operations = [
        migrations.RenameField(
            model_name='guest_account',
            old_name='Title',
            new_name='title',
        ),
    ]
