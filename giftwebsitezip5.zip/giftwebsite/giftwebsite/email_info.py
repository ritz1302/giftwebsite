EMAIL_USE_TLS = True
DEFAULT_FROM_EMAIL = 'ritz.0213@gmail.com'
SERVER_EMAIL = 'ritz.0213@gmail.com'
EMAIL_HOST = 'smtp.gmail.com'
EMAIL_PORT = 587
EMAIL_HOST_USER = 'ritz.0213@gmail.com'
EMAIL_HOST_PASSWORD = 'Ritu#321'
EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
